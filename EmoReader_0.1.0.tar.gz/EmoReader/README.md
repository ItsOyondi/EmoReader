The dataset that we will be working is the Amazon's Mobile Electronics review.
Dataset: https://s3.amazonaws.com/amazon-reviews-pds/tsv/amazon_reviews_us_Mobile_Electronics_v1_00.tsv.gz

Dataset: https://s3.amazonaws.com/amazon-reviews-pds/tsv/index.txt
