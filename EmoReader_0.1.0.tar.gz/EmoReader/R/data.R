#' Amazon Customer Review Dataset
#'
#' This is a  subset of data from the amazon Customer review dataset
#' Report ...
#'
#' @format ## `amazon_data`
#' A data frame with 500 rows and 2 columns:
#' \describe{
#'   \item{star_rating}{The number of star rating given by the user on their review}
#'   \item{review}{The review/feedback given by customer on the product}
#' }
#' @source <https://s3.amazonaws.com/amazon-reviews-pds/tsv/index.txt>
"amazon_data"


